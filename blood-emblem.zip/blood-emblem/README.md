# Blood-Emblem

A starter project for an HD-2D style game: crisp pixel-art sprites standing in a lit, shadowed 3D world, built with [Three.js](https://threejs.org/) and [Vite](https://vitejs.dev/).

## Run it

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Controls

WASD or the arrow keys to move.

## What's in the prototype

- A procedurally generated pixel-art stone floor and pillars (nearest-neighbour filtering keeps pixels sharp)
- A 12x16 pixel hero sprite defined as text rows in `src/main.js`, drawn as an upright billboard
- Fixed-angle perspective camera that follows the player
- Moonlight plus a flickering torch light with real shadows
- Simple movement and pillar collision

## Layout

```
blood-emblem/
  index.html      page shell + HUD
  package.json
  src/main.js     scene, sprites, input, game loop
```

## Ideas for next steps

- Post-processing: depth-of-field / tilt-shift blur and bloom (the signature HD-2D look)
- Load sprite sheets (PNG) and add walk animations
- Tilemap-based levels instead of a flat floor
- Game state, UI, and combat once the concept details are set
