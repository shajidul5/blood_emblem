import * as THREE from 'three';

// ---------------------------------------------------------------
// Blood-Emblem: minimal HD-2D style prototype
// Pixel-art sprites (nearest-neighbour) standing in a lit 3D scene.
// ---------------------------------------------------------------

const WORLD_SIZE = 24;          // floor is WORLD_SIZE x WORLD_SIZE tiles
const PLAYER_SPEED = 5;         // tiles per second
const PLAYER_RADIUS = 0.35;

// ---------- Helpers ----------

function pixelTexture(canvas) {
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// Small seeded RNG so textures look the same every run
function rng(seed) {
  let s = seed;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

function makeStoneCanvas(base, seed) {
  const size = 16;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d');
  const r = rng(seed);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const n = (r() - 0.5) * 22;
      const v = (i) => Math.max(0, Math.min(255, base[i] + n));
      g.fillStyle = `rgb(${v(0)},${v(1)},${v(2)})`;
      g.fillRect(x, y, 1, 1);
    }
  }
  // tile edge lines
  g.fillStyle = 'rgba(0,0,0,0.35)';
  g.fillRect(0, 0, size, 1);
  g.fillRect(0, 0, 1, size);
  return c;
}

// ---------- Sprite art (12x16) ----------

const PALETTE = {
  k: '#14090f', // outline
  h: '#2b2438', // hair
  s: '#e3b79a', // skin
  r: '#b3202c', // cloak
  d: '#6e1119', // cloak shadow
  w: '#f2e6d8', // emblem
  b: '#4a2f22', // boots
};

const HERO = [
  '....kkkk....',
  '...khhhhk...',
  '..khhhhhhk..',
  '..khssssshk.',
  '..kskssksk..',
  '..ksssssssk.',
  '...kkssskk..',
  '..krrrrrrrk.',
  '.krrrrwrrrrk',
  '.krrrwwwrrrk',
  '.krrrrwrrrrk',
  '.kdrrrrrrrdk',
  '..kddddddk..',
  '...kbkkbk...',
  '...kbk.kbk..',
  '...kkk.kkk..',
];

function spriteTexture(rows) {
  const h = rows.length;
  const w = rows[0].length;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const g = c.getContext('2d');
  rows.forEach((row, y) => {
    [...row].forEach((ch, x) => {
      if (ch === '.') return;
      g.fillStyle = PALETTE[ch];
      g.fillRect(x, y, 1, 1);
    });
  });
  return pixelTexture(c);
}

function blobShadowTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d');
  const grad = g.createRadialGradient(32, 32, 2, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0,0,0,0.55)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

// ---------- Renderer / scene / camera ----------

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0710);
scene.fog = new THREE.Fog(0x0b0710, 14, 30);

const camera = new THREE.PerspectiveCamera(
  28,
  window.innerWidth / window.innerHeight,
  0.1,
  100,
);
const CAM_OFFSET = new THREE.Vector3(0, 9, 11); // fixed angle, HD-2D style

// ---------- Lighting ----------

scene.add(new THREE.AmbientLight(0x4a3a66, 0.9));

const moon = new THREE.DirectionalLight(0x9fb4ff, 0.8);
moon.position.set(-8, 14, 6);
moon.castShadow = true;
moon.shadow.mapSize.set(2048, 2048);
moon.shadow.camera.left = -16;
moon.shadow.camera.right = 16;
moon.shadow.camera.top = 16;
moon.shadow.camera.bottom = -16;
scene.add(moon);

const torch = new THREE.PointLight(0xff7a3c, 40, 12, 2);
torch.castShadow = true;
scene.add(torch);

// ---------- World ----------

// Floor
const floorTex = pixelTexture(makeStoneCanvas([74, 66, 84], 7));
floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
floorTex.repeat.set(WORLD_SIZE, WORLD_SIZE);
const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE),
  new THREE.MeshStandardMaterial({ map: floorTex, roughness: 1 }),
);
floor.rotation.x = -Math.PI / 2;
floor.receiveShadow = true;
scene.add(floor);

// Pillars (also act as simple obstacles)
const pillarTex = pixelTexture(makeStoneCanvas([112, 98, 120], 21));
const pillarMat = new THREE.MeshStandardMaterial({ map: pillarTex, roughness: 1 });
const obstacles = [];
const pillarSpots = [
  [-4, -4], [4, -4], [-4, 3], [4, 3], [0, -8], [-8, 0], [8, 0], [0, 7],
];
for (const [x, z] of pillarSpots) {
  const height = 3 + ((x * 7 + z * 13) & 1);
  const m = new THREE.Mesh(new THREE.BoxGeometry(1.2, height, 1.2), pillarMat);
  m.position.set(x, height / 2, z);
  m.castShadow = true;
  m.receiveShadow = true;
  scene.add(m);
  obstacles.push({ x, z, half: 0.6 });
}

// Player
const heroTex = spriteTexture(HERO);
const HERO_H = 1.6;
const HERO_W = HERO_H * (12 / 16);
const hero = new THREE.Mesh(
  new THREE.PlaneGeometry(HERO_W, HERO_H),
  new THREE.MeshBasicMaterial({
    map: heroTex,
    alphaTest: 0.5,
    side: THREE.DoubleSide,
  }),
);
hero.position.y = HERO_H / 2;
scene.add(hero);

const blob = new THREE.Mesh(
  new THREE.PlaneGeometry(1.1, 1.1),
  new THREE.MeshBasicMaterial({
    map: blobShadowTexture(),
    transparent: true,
    depthWrite: false,
  }),
);
blob.rotation.x = -Math.PI / 2;
blob.position.y = 0.02;
scene.add(blob);

const player = { x: 0, z: 2, facing: 1 };

// ---------- Input ----------

const keys = new Set();
window.addEventListener('keydown', (e) => keys.add(e.code));
window.addEventListener('keyup', (e) => keys.delete(e.code));

// ---------- Movement / collision ----------

function collides(x, z) {
  const lim = WORLD_SIZE / 2 - 0.5;
  if (Math.abs(x) > lim || Math.abs(z) > lim) return true;
  for (const o of obstacles) {
    const dx = Math.max(Math.abs(x - o.x) - o.half, 0);
    const dz = Math.max(Math.abs(z - o.z) - o.half, 0);
    if (dx * dx + dz * dz < PLAYER_RADIUS * PLAYER_RADIUS) return true;
  }
  return false;
}

function update(dt, t) {
  let ix = 0;
  let iz = 0;
  if (keys.has('KeyA') || keys.has('ArrowLeft')) ix -= 1;
  if (keys.has('KeyD') || keys.has('ArrowRight')) ix += 1;
  if (keys.has('KeyW') || keys.has('ArrowUp')) iz -= 1;
  if (keys.has('KeyS') || keys.has('ArrowDown')) iz += 1;

  if (ix || iz) {
    const len = Math.hypot(ix, iz);
    const step = PLAYER_SPEED * dt;
    const nx = player.x + (ix / len) * step;
    const nz = player.z + (iz / len) * step;
    if (!collides(nx, player.z)) player.x = nx;
    if (!collides(player.x, nz)) player.z = nz;
    if (ix) player.facing = ix > 0 ? 1 : -1;
  }

  hero.position.x = player.x;
  hero.position.z = player.z;
  hero.scale.x = player.facing;
  // little walking bob
  const moving = ix || iz;
  hero.position.y = HERO_H / 2 + (moving ? Math.abs(Math.sin(t * 12)) * 0.08 : 0);
  blob.position.x = player.x;
  blob.position.z = player.z;

  // torch follows the hero with a flicker
  torch.position.set(player.x + 1.2, 2.4, player.z + 0.8);
  torch.intensity = 38 + Math.sin(t * 17) * 3 + Math.sin(t * 5.3) * 2;

  // smooth camera follow
  const target = new THREE.Vector3(player.x, 0.8, player.z);
  const desired = target.clone().add(CAM_OFFSET);
  camera.position.lerp(desired, 1 - Math.pow(0.001, dt));
  camera.lookAt(target);
}

// ---------- Main loop ----------

const clock = new THREE.Clock();
function frame() {
  const dt = Math.min(clock.getDelta(), 0.05);
  update(dt, clock.elapsedTime);
  renderer.render(scene, camera);
  requestAnimationFrame(frame);
}
frame();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
